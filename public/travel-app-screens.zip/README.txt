SCREEN FILES — TRAVEL APP
==========================

Navigation flow:
  Tab 1: Trips → Trip Overview → Incident Workspace → Claim Builder
  Tab 2: Segments (with Report Disruption)
  Tab 3: Incidents (global dashboard)
  Tab 4: Coverage
  Tab 5: Account

FILES
-----
00  TripHomeScreen            Main app shell. Manages all tab routing and deep
                               navigation stack (tripOverview, incidentWorkspace,
                               claimBuilder states). Import this as the root component.

01  SharedShell               StatusBar, HomeIndicator, BottomTabBar.
                               Tabs: Trips / Segments / Incidents / Coverage / Account.

02  TripsScreen               Tab 1. Shows Active / Upcoming / Past trip cards.
                               Each card has incident summary row (open/resolved counts)
                               and "Open trip" CTA that navigates to TripOverviewScreen.

03  TripOverviewScreen        Trip detail screen. Sections: Quick Actions, Trip Segments,
                               Incidents. "Report incident" sheet with pre-fill support.
                               Tapping a segment shows detail + Report disruption button.

04  RoutesScreen              Tab 2. Segment list per trip. Each expanded segment card
                               has "Edit route" + "Report disruption" buttons side by side.

05  IncidentsDashboard        Tab 3 (formerly EventsScreen). Global incidents list across
                               all trips. Each card: Open workspace / Resolve actions.
                               "Log incident" + "Narrate" in header.

06  IncidentWorkspaceScreen   Deep screen. Opens from any incident card. Shows:
                               - Status progress bar (5 steps)
                               - Timeline (collapsible)
                               - Evidence Locker (upload/scan/attach/document)
                               - Airline Actions (+ Add action sheet)
                               - Coverage Eligibility (View requirements / Start claim)
                               - Claim Routing (numbered recommended order)

07  ClaimBuilderScreen        Final screen. Auto-filled from incident + coverage.
                               Generates claim email draft. Copy email / Download PDF.

08  AccountScreen             Tab 5. Profile, membership, settings.

09  EmergencySystem           SOS emergency panel. Referenced by TripHomeScreen.

10  LockScreen                Lock / splash screen shown before main app.

11  NewTripFlow               Sheet/flow for creating a new trip, launched from TripsScreen.

