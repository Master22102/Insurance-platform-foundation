"use client";

import { useState } from "react";

// ---------------------------------------------------------------------------
// CLAIM BUILDER SCREEN
// ---------------------------------------------------------------------------
export default function ClaimBuilderScreen({ incident, coverage, onBack }) {
  const [step, setStep] = useState("review"); // review | generating | done
  const [copied, setCopied] = useState(false);

  const incData = incident || {
    title: "Flight Delay",
    flightNum: "AC780",
    route: "Toronto → Boston",
    date: "Oct 9, 2025",
    delayLength: "2 hours 40 minutes",
    expenses: "$47.50 (meal at airport)",
    evidence: ["BoardingPass_AC780.pdf", "Gate_Delay_Notice.jpg"],
  };

  const covData = coverage || {
    label: "Credit card trip delay",
    payout: "$500",
    type: "card",
  };

  const claimEmail = `Subject: Trip Delay Claim — ${incData.flightNum} — ${incData.date}

To Whom It May Concern,

I am writing to submit a trip delay claim under my credit card travel benefit.

Flight details:
  Flight number: ${incData.flightNum}
  Route: ${incData.route}
  Date: ${incData.date}
  Delay duration: ${incData.delayLength}

Out-of-pocket expenses incurred due to the delay:
  ${incData.expenses}

Evidence attached:
  ${(incData.evidence || []).join("\n  ")}

Please process this claim at your earliest convenience. I can be reached at the contact information on file with my account.

Thank you,
[Cardholder name]`;

  function handleGenerate() {
    setStep("generating");
    setTimeout(() => setStep("done"), 1800);
  }

  function handleCopy() {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: "#f5f5f7", position: "relative" }}>
      {/* Header */}
      <div style={{ padding: "8px 16px 12px", flexShrink: 0 }}>
        <button
          onClick={onBack}
          style={{ background: "none", border: "none", padding: "0 0 8px", cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }}
        >
          <svg width="7" height="12" viewBox="0 0 7 12" fill="none"><path d="M6 1L1 6l5 5" stroke="#1d4ed8" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#1d4ed8" }}>Incident Workspace</span>
        </button>
        <p style={{ fontSize: 22, fontWeight: 700, color: "#111", margin: 0, letterSpacing: "-0.3px" }}>Build Claim</p>
        <p style={{ fontSize: 12, color: "#6b7280", margin: "2px 0 0" }}>{covData.label}</p>
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 16px 40px" }}>
        {/* Auto-filled fields */}
        <div style={{ background: "white", borderRadius: 14, border: "1px solid #f0f0f0", padding: "14px", boxShadow: "0 1px 3px rgba(0,0,0,0.04)", marginBottom: 12 }}>
          <p style={{ fontSize: 11, fontWeight: 700, color: "#9ca3af", margin: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.05em" }}>Claim details</p>
          {[
            { label: "Incident type", value: incData.title },
            { label: "Flight number", value: incData.flightNum },
            { label: "Route", value: incData.route },
            { label: "Date", value: incData.date },
            { label: "Delay length", value: incData.delayLength },
            { label: "Expenses", value: incData.expenses },
            { label: "Coverage type", value: covData.label },
            { label: "Potential payout", value: covData.payout },
          ].map((field) => (
            <div key={field.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 10, marginBottom: 10, borderBottom: "1px solid #f5f5f5" }}>
              <span style={{ fontSize: 12, color: "#9ca3af", fontWeight: 500 }}>{field.label}</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: "#111", textAlign: "right", maxWidth: "55%" }}>{field.value}</span>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <span style={{ fontSize: 12, color: "#9ca3af", fontWeight: 500 }}>Evidence files</span>
            <div style={{ textAlign: "right" }}>
              {(incData.evidence || []).map((f) => (
                <p key={f} style={{ fontSize: 12, fontWeight: 600, color: "#1d4ed8", margin: "0 0 2px" }}>{f}</p>
              ))}
            </div>
          </div>
        </div>

        {step === "review" && (
          <button
            onClick={handleGenerate}
            style={{
              width: "100%", padding: "14px 0",
              background: "linear-gradient(135deg, #1e3a5f 0%, #0f2440 100%)",
              border: "none", borderRadius: 14,
              fontSize: 14, fontWeight: 600, color: "white", cursor: "pointer",
              boxShadow: "0 4px 16px rgba(30,58,95,0.3)",
            }}
          >
            Generate claim packet
          </button>
        )}

        {step === "generating" && (
          <div style={{ background: "white", borderRadius: 14, border: "1px solid #f0f0f0", padding: "24px", textAlign: "center", boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", border: "3px solid #1e3a5f", borderTopColor: "transparent", animation: "spin 0.8s linear infinite", margin: "0 auto 14px" }} />
            <p style={{ fontSize: 14, fontWeight: 600, color: "#111", margin: "0 0 4px" }}>Preparing your claim...</p>
            <p style={{ fontSize: 12, color: "#9ca3af", margin: 0 }}>Compiling evidence and generating documents</p>
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
          </div>
        )}

        {step === "done" && (
          <>
            <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 12, padding: "12px 13px", marginBottom: 14, display: "flex", gap: 8, alignItems: "flex-start" }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0, marginTop: 1 }}>
                <circle cx="12" cy="12" r="9" stroke="#059669" strokeWidth="1.6"/>
                <path d="M9 12l2 2 4-4" stroke="#059669" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <p style={{ fontSize: 13, fontWeight: 600, color: "#059669", margin: 0 }}>
                Claim packet ready — 3 documents compiled
              </p>
            </div>

            {/* Claim email preview */}
            <div style={{ background: "white", borderRadius: 14, border: "1px solid #f0f0f0", padding: "14px", boxShadow: "0 1px 3px rgba(0,0,0,0.04)", marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <p style={{ fontSize: 12, fontWeight: 700, color: "#111", margin: 0 }}>Claim email draft</p>
                <span style={{ fontSize: 10, color: "#9ca3af" }}>Ready to send</span>
              </div>
              <div style={{ background: "#f9fafb", borderRadius: 10, padding: "11px 12px", maxHeight: 160, overflowY: "auto" }}>
                <pre style={{ fontSize: 11, color: "#374151", margin: 0, whiteSpace: "pre-wrap", fontFamily: "system-ui, sans-serif", lineHeight: 1.6 }}>
                  {claimEmail}
                </pre>
              </div>
            </div>

            {/* Action buttons */}
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <button
                onClick={handleCopy}
                style={{
                  width: "100%", padding: "13px 0",
                  background: copied ? "linear-gradient(135deg, #059669 0%, #047857 100%)" : "linear-gradient(135deg, #1e3a5f 0%, #0f2440 100%)",
                  border: "none", borderRadius: 13,
                  fontSize: 13, fontWeight: 600, color: "white", cursor: "pointer",
                  transition: "background 0.2s",
                }}
              >
                {copied ? "Copied to clipboard" : "Copy claim email"}
              </button>
              <button
                style={{
                  width: "100%", padding: "13px 0",
                  background: "none", border: "1.5px solid #e5e7eb",
                  borderRadius: 13, fontSize: 13, fontWeight: 600, color: "#374151", cursor: "pointer",
                }}
              >
                Download PDF claim
              </button>
              <button
                style={{
                  width: "100%", padding: "13px 0",
                  background: "none", border: "1.5px solid #e5e7eb",
                  borderRadius: 13, fontSize: 13, fontWeight: 600, color: "#374151", cursor: "pointer",
                }}
              >
                Generate claim packet
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
